default_app_config = "common.apps.CommonConfig"

__all__ = ["default_app_config"]
